#ifndef APP_GYRO_H
#define APP_GYRO_H

/*
 * app_gyro.h
 * 陀螺仪 (IMU) 模块头文件
 *
 * 硬件映射:
 *   SPI1 (PB3/PB4/PB5) Master, CS = PD7 (软件控制)
 *   中断: PB6 EXTI 下降沿 (数据就绪)
 *
 * 与原始代码差异:
 *   原始: imu963ra_init() / imu963ra_get_gyro() / imu963ra_gyro_z (逐飞库)
 *   现在: 通过 SPI1 直接读写 IMU 寄存器
 *
 * ⚠️ 重要: 需要根据实际 IMU 芯片型号 (ICM-20602 / MPU-6500 / BMI088 等)
 *   修改 app_gyro.c 中的寄存器地址和初始化序列
 *   当前默认使用 ICM-20602 寄存器定义
 *
 * 陀螺仪缩放因子:
 *   原始代码: oncez = (float)(imu963ra_gyro_z) / 7.05
 *   IMU963RA 的灵敏度约 7.05 LSB/(°/s) 在 ±2000°/s 量程
 *   ICM-20602 ±2000°/s: 灵敏度 = 16.4 LSB/(°/s)
 *   → 如果使用 ICM-20602, 需将 GYRO_SCALE_FACTOR 改为 16.4
 *   → 必须保证 oncez 的物理意义 (°/s) 与原始代码一致
 */

#include "main.h"

/* ---- IMU 缩放因子 (根据实际芯片修改!) ---- */
#define GYRO_SCALE_FACTOR   7.05f   // ← 与原始 imu963ra 一致, 换芯片时修改

/* ---- 导出变量 (与原始代码完全一致) ---- */
extern float jiaoduz, jiaodux, jiaoduy;         // 积分角度 Z/X/Y (°)
extern float jiaoduz_l, jiaodux_l, jiaoduy_l;   // 上一次角度
extern float wenpiao;                            // 零漂
extern float oncez;                              // 单次角速度读数 (°/s, 含零漂)
extern float jiaosudu;                           // 去零漂角速度 (°/s)

/* 路径记忆 */
extern float length, once_L;
extern float now_x, now_y;
extern int   num_coord;
extern int   coord[200][2];
extern float pi;

/* 角速度环 */
extern float jiaosuderror, jiaosuderrorl;
extern float jiaosudutobe, duty;
extern float P_A, I_A;

/* ---- 函数声明 ---- */
void  app_gyro_init(void);              // IMU 初始化 + 零漂校准
void  app_gyro_get(void);               // 读取角速度 + 积分 (1ms 调用)
void  path_menmory(void);               // 路径记录 (算法不变)
void  angle_ring(int mode);             // 角速度环 (算法不变)

#endif /* APP_GYRO_H */
